from agents.spacex_agent import SpaceXAgent
from agents.weather_agent import WeatherAgent
from agents.summarizer_agent import SummarizerAgent

class PlannerAgent:
    def handle_goal(self, goal: str):
        print(f"Planner received goal: {goal}")

        print("\nStep 1: Fetching next SpaceX launch...")
        launch_data = SpaceXAgent().get_next_launch()

        print("\nStep 2: Getting weather at launch site...")
        weather = WeatherAgent().get_weather(launch_data['location'], launch_data['date'])

        print("\nStep 3: Summarizing launch condition...")
        summary = SummarizerAgent().summarize(launch_data, weather)

        return summary
