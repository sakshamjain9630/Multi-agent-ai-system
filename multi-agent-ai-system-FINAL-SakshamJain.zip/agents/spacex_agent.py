import requests

class SpaceXAgent:
    def get_next_launch(self):
        res = requests.get("https://api.spacexdata.com/v5/launches/upcoming")
        res.raise_for_status()
        data = res.json()[0]  # get first upcoming launch
        return {
            "name": data["name"],
            "date": data["date_utc"],
            "location": data["launchpad"]
        }
