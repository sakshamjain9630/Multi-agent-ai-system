import requests
import os
from dotenv import load_dotenv
load_dotenv()

class WeatherAgent:
    def get_weather(self, location_id, date):
        launchpad_url = f"https://api.spacexdata.com/v4/launchpads/{location_id}"
        loc_data = requests.get(launchpad_url).json()
        lat, lon = loc_data["latitude"], loc_data["longitude"]

        api_key = os.getenv("OPENWEATHER_API")
        weather_url = f"https://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={api_key}&units=metric"
        weather_data = requests.get(weather_url).json()

        return {
            "temperature": weather_data["main"]["temp"],
            "description": weather_data["weather"][0]["description"],
            "wind": weather_data["wind"]["speed"]
        }
