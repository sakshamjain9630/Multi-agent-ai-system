class SummarizerAgent:
    def summarize(self, launch_data, weather):
        conditions = weather["description"].lower()
        delay_possible = any(word in conditions for word in ["storm", "rain", "wind", "cloud"])

        summary = f"Launch: {launch_data['name']} on {launch_data['date']}\n"
        summary += f"Weather: {weather['description']}, Temp: {weather['temperature']}°C, Wind: {weather['wind']} m/s\n"
        summary += "🚀 Possible delay due to weather." if delay_possible else "✅ No major weather concerns."

        return summary
