# Multi-Agent AI System: SpaceX Weather Evaluation

## 📌 Project Description
A multi-agent AI system that determines whether the next SpaceX launch may face weather-related delays.

## 🧠 Agents
- **PlannerAgent**: Orchestrates the process.
- **SpaceXAgent**: Fetches launch info.
- **WeatherAgent**: Gets weather data.
- **SummarizerAgent**: Predicts delay.

## 🌐 APIs Used
- SpaceX API
- OpenWeatherMap API

## 🛠️ Setup
1. Create `.env` with:
```
OPENWEATHER_API=your_api_key_here
```
2. Run:
```
python main.py
```

## ✅ Example Output
```
Launch: Starlink Mission on 2025-06-18
Weather: scattered clouds, Temp: 29°C, Wind: 3.5 m/s
✅ No major weather concerns.
```
