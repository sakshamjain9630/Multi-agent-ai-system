from agents.planner import PlannerAgent

def main():
    user_goal = "Check if the next SpaceX launch may be delayed due to weather."
    planner = PlannerAgent()
    result = planner.handle_goal(user_goal)
    print("\nFinal Summary:\n", result)

if __name__ == "__main__":
    main()
